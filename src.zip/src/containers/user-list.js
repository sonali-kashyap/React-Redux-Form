import React, {Component} from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {selectUser} from '../actions/index'


class UserList extends Component {

    constructor(props) {
        super(props);
        this.state= {
            Username : '',
            Password : '',
            validate : 'Invalid Credentials!!'
        }

        this.onChange=this.onChange.bind(this);
        this.handleReset=this.handleReset.bind(this);
        this.handleSubmit=this.handleSubmit.bind(this);
        this.validate=this.validate.bind(this);
        
    }

    onChange(e) {
        this.setState({[e.target.name] : e.target.value});
    }

    handleReset(e) {
        e.preventDefault();
        this.setState(
        {
            Username : '',
            Password : '',
            validate : ''
        });
    }

    validate ()  {
        let isError=true;
        const pass = ["bucky_01","joby_020","madi_03"];
        for(let i=0;i<pass.length;i++)
        {
            if(this.state.Password === pass[i])
            {
                isError=false;
                return isError;
            }
        }
        return isError;
    }

    handleSubmit (e) {
        e.preventDefault();
    }

    renderList() {
      return this.props.users.map((user) => {
        
        if(!this.validate()  ) 
        
             {if( user.id == this.state.Username)
                                 {      
                                     console.log(user.id + "    " + this.state.Username);
                                     return (     
                                             <div>
                                                 <br /><button onClick={() => this.props.selectUser(user) }>Submit</button>
                                             </div>
                                             );
                                 }}
                });
    }

    render() {
        return (
        <div>
        <form onSubmit={this.handleReset}>
            Username : <input type='text' name='Username' 
            value={this.state.Username} onChange={this.onChange} /> <br/> <br/>
            Password : <input type='password' name='Password' 
            value={this.state.Password} onChange={this.onChange} /> <br/> <br/>

            <button onClick={this.handleReset}>Reset</button>
            

            
        </form>
        <div>{this.renderList()}</div>
        </div>
            
        );
    }

}

// Get apps state and pass it as props to UserList
//      > whenever state changes, the UserList will automatically re-render
function mapStateToProps(state) {
    return {
        users: state.users
    };
}

// Get actions and pass them as props to to UserList
//      > now UserList has this.props.selectUser
function matchDispatchToProps(dispatch){
    return bindActionCreators({selectUser: selectUser}, dispatch);
}

// We don't want to return the plain UserList (component) anymore, we want to return the smart Container
//      > UserList is now aware of state and actions
export default connect(mapStateToProps, matchDispatchToProps)(UserList);
